# OFFIRST Patient Screening PDF Report — Reference Spec

## Pages & Layout (A4 Portrait)
- **Page 1:**
  1. **Header:** Title (`OFFIRST Retinal Screening Report`), subtitle, `Report ID`, date/time, camp/site.
  2. **Patient Details Card:** Name, Patient ID, Age/Sex, Contact, Known Diabetes, Eyes Captured (OD/OS), Operator, Capture Device.
  3. **Overall Triage Banner:** Color-coded to the worst eye's DR severity (`Healthy` / `Mild` / `Moderate` / `Severe`), with one-line plain-language recommended action.
  4. **DR Severity Index:** Per-eye 4-segment colored bar (`Healthy #22C55E`, `Mild #EAB308`, `Moderate #F97316`, `Severe #EF4444`) with active segment highlighted and grade + confidence on the right.
  5. **Other Screening Findings (Multi-Disease):** Table of flagged conditions (excluding DR) with a color-coded severity/signal pill next to each (`Borderline` `#EAB308` when just above `thr_youden_cv` or `< 0.70`, `Moderate` `#F97316` for `0.70–0.85`, `High / Marked` `#EF4444` for `>= 0.85`), plus a compact `Not Flagged (Low Risk)` footer line for unflagged heads.
  6. **Tip: How to Read Your Color-Coded Result:** 4-card color legend explaining Green, Yellow, Orange, and Red.
  7. **Clinician Confirmation & Disclaimer Footer:** Optional doctor confirmation/grade/signature strip + screening-only disclaimer + `Page 1 of 2`.

- **Page 2:**
  1. **Compact Header:** Title (`Retinal Fundus Photographs`), Patient Name/ID, `Report ID`.
  2. **Vertical Eye Photos Stack:** Right Eye (OD) card on top, Left Eye (OS) card below, each with dark rounded image container, per-eye status pills, and image quality/summary caption.
  3. **Footer:** `Page 2 of 2`.

## Color Palette
- Healthy / Not Flagged: `#22C55E` (bg `#DCFCE7`, text `#166534`)
- Mild / Borderline: `#EAB308` (bg `#FEF9C3`, text `#854D0E`)
- Moderate: `#F97316` (bg `#FFEDD5`, text `#9A3412`)
- Severe / High: `#EF4444` (bg `#FEE2E2`, text `#991B1B`)
